import os
import sys

def main():
    print(sys.argv)
    print(os.getcwd())
    print("hello-world")